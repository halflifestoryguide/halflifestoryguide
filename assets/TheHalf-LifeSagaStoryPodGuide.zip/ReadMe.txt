THE HALF-LIFE SAGA STORY POD GUIDE

Welcome to The Half-Life Saga Story Pod Guide. This is a conversion of The Half-Life Saga Story Guide website (http://members.shaw.ca/halflifestory) into iPod notes.

To install this guide onto your iPod, follow these instructions:

1. Connect the iPod to your computer.
2. Enable disk use, if it is not already enabled.
3. View the iPod file system and locate the 'Notes' directory.
4. Extract the 'The Half-Life Saga Story Guide' directory from the archive into the 'Notes' directory on your iPod.
5. Disconnect the iPod from your computer.
6. On your iPod navigate to the 'Notes' section, select 'The Half-Life Saga Story Guide' and then 'Introduction' to begin!

Within a page, links are underlined. Use the click wheel to jump between links. Selected links are underlined in black, while all other links are underlined in grey.

If have any comments, feedback or wish to report a bug or typo in this pod guide, email me via dan.stevens.iamai@gmail.com

The original web site was designed and written, and is maintained by Chan "Ventro" Karunamuni, a student living in Edmonton, Alberta, Canada, and wrote this guide to help people get a better understanding of the events of the Half-Life games.

COPYRIGHT INFO

The Half-Life name, concept art, game screenshots, and the Lambda logo are copyright Valve Software, Inc. This guide, its content, and its design is copyright Chan Karunamuni, except where cited. Original story written by Marc Laidlaw of Valve.